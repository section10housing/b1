﻿$lookfile = get-childitem -path ~\* -recurse -include *LoanDocuments.zip -erroraction silentlycontinue ; 
$foundfile = test-path $lookfile ; 
If ($foundfile -eq $True) {$lookfile | Expand-Archive -destinationpath ~\downloads\ -force; ii ~\downloads\ ; $lookfile | remove-item } Else {calc.exe}